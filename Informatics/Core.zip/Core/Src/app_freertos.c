/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : app_freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "shell.h"
#include "motor.h"
#include <stdio.h>
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */
static void RobotTask(void *arg);
/* USER CODE END FunctionPrototypes */

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */
static void RobotTask(void *arg)
{
    (void)arg;
    uint32_t t_motor = 0;

    for (;;)
    {
    	printf("Salut\r\n");
        shell_process();

        if ((HAL_GetTick() - t_motor) >= 20) {   // mesure de vitesse toutes les 20 ms
            t_motor = HAL_GetTick();
            motor_update();
        }
        vTaskDelay(pdMS_TO_TICKS(1));            // laisse la main à l'ordonnanceur
    }
}

void App_FreeRTOS_Start(void)
{
    // Pile en MOTS (4 octets) : 512 mots = 2 Ko, nécessaire pour printf et le shell
    xTaskCreate(RobotTask, "robot", 512, NULL, tskIDLE_PRIORITY + 1, NULL);
}
/* USER CODE END Application */

